#!/usr/bin/env python3
import socket
import os
import sys
import time
import json
import requests
import random
import re
import subprocess
import sqlite3
import shutil
import signal
from datetime import datetime

# ======================================================================
# GLOBAL SILENT & EVASION MODE
# ======================================================================
try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass

# ======================================================================
# KONFIGURATION v150 (THE OMEGA SOVEREIGN)
# ======================================================================

# --- API-KONFIGURATION ---
API_KEY_STORAGE = "sk-..." # Optionaler Hardcode-Platz
MODEL_OPENAI = "gpt-4o"
MODEL_GEMINI = "gemini-2.5-flash-preview-09-2025"

DB_FILE = "pentest_history.db"
KEY_FILE = ".api_key"
REPORT_DIR = "reports"

# Evasion-Daten (Gegen Cloudflare, WAF, IDS, KI-Abwehr)
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
]

PRIORITY_PORTS = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 
    80: "http", 110: "pop3", 111: "rpcbind", 135: "msrpc", 
    139: "netbios", 143: "imap", 443: "https", 445: "smb", 
    993: "imaps", 995: "pop3s", 1723: "pptp", 3306: "mysql", 
    3389: "rdp", 5900: "vnc", 8080: "http-proxy"
}

NIKTO_PATHS = [
    "/admin", "/.env", "/.git/config", "/backup", "/config.php", 
    "/wp-admin", "/login", "/phpinfo.php", "/.htaccess", "/api/v1",
    "/server-status", "/storage", "/etc/passwd", "/.ssh/id_rsa"
]

PROFILES = {
    "1": {"name": "RECON ONLY", "desc": "Nur Ports & Banner", "phases": [1], "delay": 0.1, "timeout": 1.5, "jitter": (0, 0.2)},
    "2": {"name": "STANDARD AUDIT", "desc": "Full Engine (Nikto+MSF+EDB)", "phases": [1, 2, 3], "delay": 1.5, "timeout": 3.5, "jitter": (0.5, 2.5)},
    "3": {"name": "GHOST SOVEREIGN", "desc": "Max Stealth & CF-Evasion", "phases": [1, 2, 3], "delay": 8.5, "timeout": 7.5, "jitter": (6.0, 30.0)}
}

state = {
    "target": "", "security_meta": {}, "useful_ports": [], "port_banners": {}, 
    "nikto_findings": [], "msf_modules": [], "exploit_db_results": [],
    "found_services": set(), "found_versions": set(),
    "past_ports": [], "new_ports": [], "lost_ports": [], "block_count": 0,
    "pre_scan_strategy": "", "executive_summary": "Lokale Analyse beendet.", "active_profile": "UNKNOWN"
}

# ======================================================================
# CORE SYSTEM: NEURAL DATABASE & TOOLS
# ======================================================================

def find_binary(name):
    """Sucht Binaries auch in UserLAnd-Home Verzeichnissen."""
    std = shutil.which(name)
    if std: return std
    home = os.path.expanduser("~")
    paths = [
        os.path.join(home, "exploitdb", name),
        os.path.join(home, "metasploit-framework", name),
        f"/opt/metasploit-framework/bin/{name}",
        f"/usr/local/bin/{name}"
    ]
    for p in paths:
        if os.path.exists(p): return p
    return None

def check_tool_status(name):
    return find_binary(name) is not None

def clean_api_key(raw_key):
    if not raw_key or raw_key.startswith("sk-..."): return ""
    return re.sub(r'[^a-zA-Z0-9\-_]', '', raw_key.strip())

def init_sql_db():
    try:
        if not os.path.exists(REPORT_DIR): os.makedirs(REPORT_DIR)
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS scans (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, target TEXT, profile TEXT, summary TEXT, full_data TEXT)')
            conn.execute('CREATE TABLE IF NOT EXISTS intelligence (target TEXT PRIMARY KEY, last_seen TEXT, block_count INTEGER, known_ports TEXT)')
            conn.commit()
    except: pass

def get_intelligence(target):
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cur = conn.cursor()
            cur.execute("SELECT block_count, known_ports FROM intelligence WHERE target = ?", (target,))
            row = cur.fetchone()
            if row: return {"blocks": row[0], "ports": json.loads(row[1])}
    except: pass
    return {"blocks": 0, "ports": []}

def save_intelligence(target, current_ports, blocked=False):
    try:
        past = get_intelligence(target)
        new_blocks = past["blocks"] + (1 if blocked else 0)
        updated_ports = list(set(past["ports"] + current_ports))
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute('''INSERT OR REPLACE INTO intelligence (target, last_seen, block_count, known_ports) 
                            VALUES (?, ?, ?, ?)''', (target, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), new_blocks, json.dumps(updated_ports)))
            conn.commit()
    except: pass

def sql_checkpoint():
    try:
        st_copy = state.copy()
        st_copy["found_services"] = list(state["found_services"])
        st_copy["found_versions"] = list(state["found_versions"])
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("INSERT INTO scans (timestamp, target, profile, summary, full_data) VALUES (?, ?, ?, ?, ?)", 
                         (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), state["target"], state["active_profile"], state["executive_summary"], json.dumps(st_copy)))
            conn.commit()
    except: pass

# ======================================================================
# CORE ENGINES: STEALTH & EXPLOITS
# ======================================================================

def detect_security_layers(target):
    print(f"\n\033[94m[*] Phase 0: Analyse der Verteidigungslinien (Firewall/WAF/VPN/KI)...\033[0m")
    results = {"firewall": "Standard", "vpn": "Negativ", "waf": "Nicht erkannt", "ai_defense": "Nicht erkannt"}
    try:
        ua = random.choice(USER_AGENTS)
        headers = {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
            "Connection": "keep-alive"
        }
        response = requests.get("http://" + target, headers=headers, timeout=5, verify=False)
        server = response.headers.get("Server", "").lower()
        
        if "cloudflare" in server: results["waf"] = "Cloudflare"
        elif "sucuri" in server: results["waf"] = "Sucuri WAF"
        
        vpn_indicators = ["Via", "X-Forwarded-For", "Forwarded"]
        if any(h in response.headers for h in vpn_indicators):
            results["vpn"] = "Proxy/VPN aktiv"
            
        if any(x in server for x in ["datadome", "imperva", "perimeterx"]):
            results["ai_defense"] = "KI-Verhaltensanalyse detektiert"
        else: results["ai_defense"] = "Keine KI-Abwehr erkannt"
    except:
        results["firewall"] = "Aggressives Filtering"

    print(f"\033[92m  [+] FW: {results['firewall']} | WAF: {results['waf']} | VPN: {results['vpn']} | KI: {results['ai_defense']}\033[0m")
    return results

def socket_probe_sovereign(target, port, timeout):
    is_open, banner, is_blocked = False, "", False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            res = s.connect_ex((target, port))
            if res == 0:
                is_open = True
                try:
                    s.settimeout(2.5)
                    s.send(b"HEAD / HTTP/1.1\r\nHost: " + target.encode() + b"\r\n\r\n" if port in [80, 443, 8080] else b"\r\n")
                    banner = s.recv(1024).decode(errors='ignore').strip()
                except: pass
            elif res in [110, 113, 104, 111]: is_blocked = True
    except: is_blocked = True
    return is_open, banner, is_blocked

def msf_tactical_batch(queries):
    msf_bin = find_binary("msfconsole")
    if not msf_bin or not queries: return []
    # FIX: String-Verkettung statt f-string mit Backslash für Python < 3.12
    search_terms = []
    for q in queries:
        clean_q = re.sub(r'[^a-zA-Z0-9.]', ' ', q)
        search_terms.append("search name:" + clean_q + " type:exploit rank:excellent")
    
    batch_cmd = "; ".join(search_terms) + "; exit"
    print(f"\n\033[94m[*] Phase 3: Metasploit-Engine Analyse ({len(queries)} Dienste)...\033[0m")
    try:
        proc = subprocess.Popen([msf_bin, '-q', '-x', batch_cmd], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        out, _ = proc.communicate(timeout=300)
        return list(set(re.findall(r'(exploit/[a-zA-Z0-9_\-/]+)', out)))
    except: return []

def searchsploit_audit(query):
    sp_bin = find_binary("searchsploit")
    if not sp_bin: return []
    try:
        clean_q = re.sub(r'[^a-zA-Z0-9.]', ' ', query)
        out = subprocess.check_output([sp_bin, "-j", clean_q], stderr=subprocess.DEVNULL, text=True, timeout=40)
        data = json.loads(out[out.find('{'):])
        return [f"EDB: {r['Title']}" for r in data.get("RESULTS_EXPLOIT", [])[:2]]
    except: return []

def ask_ai_bridge(key, target, mode, context):
    is_openai = key.startswith("sk-")
    url = "https://api.openai.com/v1/chat/completions" if is_openai else "https://generativelanguage.googleapis.com/v1beta/models/" + MODEL_GEMINI + ":generateContent?key=" + key
    sys_p = "Du bist ein taktischer Red-Team Lead. Antworte präzise auf Deutsch."
    
    if mode == "strategy":
        user_p = "Strategie für " + target + ". Ports: " + str(context['ports']) + ". Security: " + str(context.get('security', {}))
    else:
        user_p = "AUDIT-RESULTAT: " + target + ". Daten: " + json.dumps(context, default=list)

    try:
        if is_openai:
            r = requests.post(url, headers={"Authorization": "Bearer " + key}, json={"model": MODEL_OPENAI, "messages": [{"role": "system", "content": sys_p}, {"role": "user", "content": user_p}]}, timeout=60)
            return r.json()['choices'][0]['message']['content']
        else:
            r = requests.post(url, json={"contents": [{"parts": [{"text": sys_p + "\n" + user_p}]}]}, timeout=60)
            return r.json()['candidates'][0]['content']['parts'][0]['text']
    except: return "KI-Analyse nicht verfügbar."

def generate_report():
    try:
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = REPORT_DIR + "/OmegaReport_" + state['target'] + "_" + ts + ".md"
        with open(filename, "w") as f:
            f.write(f"# 🛡️ Omega Sovereign Audit: {state['target']}\n\nZeit: {datetime.now()}\nProfil: {state['active_profile']}\n\n")
            f.write(f"## Security\n{json.dumps(state['security_meta'], indent=2)}\n\n")
            f.write(f"## Ergebnis\n{state['executive_summary']}\n\n")
        print(f"\n\033[92m[+] Bericht erstellt: {filename}\033[0m")
    except: pass

# ======================================================================
# UI & MAIN
# ======================================================================

def display_banner(key):
    os.system('clear')
    msf_ok = "\033[92mOK\033[0m" if check_tool_status("msfconsole") else "\033[91mNO\033[0m"
    ai_ok = "\033[92mOK\033[0m" if key else "\033[91mNO\033[0m"
    print("\033[96m   ____  __  ____________ ___ \n  / __ \\/  |/  / ____/ __ \\/   | \n / / / / /|_/ / __/ / / _  / /| | \n/ /_/ / /  / / /___/ /_/ / ___ | \n\\____/_/  /_/_____/\\____/_/  |_| \n        OMEGA SOVEREIGN v150\033[0m")
    print(f"\033[91m" + "="*50 + f"\n AI: {ai_ok} | MSF: {msf_ok} | MEMORY: \033[92mAKTIV\033[0m\n" + "="*50 + "\033[0m")

def main():
    init_sql_db()
    key = ""
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "r") as f: key = clean_api_key(f.read())
    
    display_banner(key)
    target = input("\033[93mZiel-Host: \033[0m").strip()
    if not target: return
    state["target"] = target.replace("http://", "").replace("https://", "").strip("/")
    
    state["security_meta"] = detect_security_layers(state["target"])
    intel = get_intelligence(state["target"])
    intel["security"] = state["security_meta"]

    if key and input("\033[96mKI-Briefing einholen? (j/n): \033[0m").lower() == 'j':
        state["pre_scan_strategy"] = ask_ai_bridge(key, state["target"], "strategy", intel)
        print(f"\n\033[97m=== KI STRATEGIE ===\n{state['pre_scan_strategy']}\n\033[0m")

    for k, p in PROFILES.items(): print(f"  [{k}] {p['name']}: {p['desc']}")
    choice = input("\n\033[93mProfil wählen (1-3): \033[0m").strip() or "2"
    profile = PROFILES.get(choice, PROFILES["2"])
    state["active_profile"] = profile["name"]

    try:
        # Phase 1: Portscan
        p_list = list(PRIORITY_PORTS.keys()); random.shuffle(p_list)
        for p in p_list:
            print(f"\033[90m  > Prüfe Port {p}...\033[0m", end="\r")
            ok, banner, blocked = socket_probe_sovereign(state["target"], p, profile["timeout"])
            if ok:
                state["useful_ports"].append(str(p))
                state["found_services"].add(PRIORITY_PORTS[p])
                if banner: state["port_banners"][p] = banner; print(f"\033[92m[+] Port {p} OFFEN: {banner[:40]}\033[0m")
                else: print(f"\033[92m[+] Port {p} OFFEN\033[0m")
            time.sleep(profile["delay"] + random.uniform(profile["jitter"][0], profile["jitter"][1]))

        # Phase 2: Web
        if 2 in profile["phases"] and "80" in state["useful_ports"]:
            print(f"\n\033[94m[*] Phase 2: Web-Audit...\033[0m")
            for path in NIKTO_PATHS:
                try:
                    r = requests.head("http://" + state["target"] + path, timeout=3, headers={"User-Agent": random.choice(USER_AGENTS)})
                    if r.status_code < 400: print(f"\033[92m  [!] Fund: {path} ({r.status_code})\033[0m")
                except: pass

        # Phase 3: Exploits
        if 3 in profile["phases"] and state["found_services"]:
            state["exploit_db_results"] = []
            for srv in list(state["found_services"]): state["exploit_db_results"].extend(searchsploit_audit(srv))
            state["msf_modules"] = msf_tactical_batch(list(state["found_services"]))

        if key and input("\n\033[96mKI-Analyse generieren? (j/n): \033[0m").lower() == 'j':
            state["executive_summary"] = ask_ai_bridge(key, state["target"], "audit", state)
            print(f"\n\033[97m{state['executive_summary']}\033[0m\n")

        save_intelligence(state["target"], state["useful_ports"])
        sql_checkpoint(); generate_report()
    except KeyboardInterrupt:
        sql_checkpoint(); generate_report(); sys.exit(0)

if __name__ == "__main__":
    main()
