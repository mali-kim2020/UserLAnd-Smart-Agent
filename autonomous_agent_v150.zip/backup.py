#!/usr/bin/env python3
import os
import zipfile
from datetime import datetime

# ======================================================================
# KONFIGURATION v1.2 (PUBLIC SAFE)
# ======================================================================
BACKUP_DIR = "backups"

# NUR Code und Logik - KEINE Keys!
FILES_TO_BACKUP = [
    "autonomous_agent.py",
    "report_generator.py",
    "pentest_history.db"  # Die DB enthält Scans, aber keine API-Keys
]

# Ordner für die Dokumentation
FOLDERS_TO_BACKUP = ["reports"]

def create_public_safe_backup():
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"{BACKUP_DIR}/omega_sovereign_safe_{ts}.zip"

    print(f"\033[96m[*] Starte Public-Safe Sicherung (Version 1.2)...\033[0m")
    print(f"\033[90m[Info] .api_key wird bewusst ignoriert.\033[0m")
    
    try:
        with zipfile.ZipFile(backup_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Dateien sichern
            for file in FILES_TO_BACKUP:
                if os.path.exists(file):
                    zipf.write(file)
                    print(f"\033[92m  [+] Gesichert: {file}\033[0m")
                else:
                    print(f"\033[91m  [-] Fehlend: {file}\033[0m")
            
            # Reports sichern
            for folder in FOLDERS_TO_BACKUP:
                if os.path.exists(folder):
                    for root, dirs, files in os.walk(folder):
                        for file in files:
                            file_path = os.path.join(root, file)
                            zipf.write(file_path)
                    print(f"\033[92m  [+] Ordner gesichert: {folder}/\033[0m")

        print(f"\n\033[92m[ERFOLG] Safe-Backup erstellt: {backup_filename}\033[0m")
        print(f"\033[93m[HINWEIS] Diese Datei kann sicher geteilt/hochgeladen werden.\033[0m")

    except Exception as e:
        print(f"\033[91m[FEHLER] Backup-Vorgang abgebrochen: {e}\033[0m")

if __name__ == "__main__":
    create_public_safe_backup()
