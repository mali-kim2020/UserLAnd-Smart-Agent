#!/usr/bin/env python3
import sqlite3
import json
import os
import ast
import re
from datetime import datetime

# ======================================================================
# KONFIGURATION
# ======================================================================
DB_FILE = "pentest_history.db"
REPORT_DIR = "reports"

def init_reports():
    if not os.path.exists(REPORT_DIR):
        os.makedirs(REPORT_DIR)

def fetch_scans():
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, timestamp, target, profile, summary FROM scans ORDER BY id DESC")
            return cursor.fetchall()
    except Exception as e:
        print(f"\033[91m[!] Fehler beim Lesen der Datenbank: {e}\033[0m")
        return []

def safe_parse_data(raw_data):
    """
    Versucht Daten sicher zu parsen, egal ob sie als valides JSON 
    oder als Python-String-Repräsentation gespeichert wurden.
    """
    if not raw_data:
        return {}
    
    # Versuch 1: Direktes JSON (v134+)
    try:
        return json.loads(raw_data)
    except json.JSONDecodeError:
        pass

    # Versuch 2: Python Literal Eval (für ganz alte v132/v133 Daten)
    try:
        # Bereinigung von set() Objekten, die ast nicht mag
        clean_data = re.sub(r"set\(\[.*?\]\)", "[]", raw_data)
        clean_data = clean_data.replace("set()", "[]")
        return ast.literal_eval(clean_data)
    except Exception as e:
        print(f"\033[93m[!] Warnung: Konnte Daten für diesen Scan nicht parsen.\033[0m")
        return {}

def generate_markdown_report(scan_id):
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT timestamp, target, profile, summary, full_data FROM scans WHERE id = ?", (scan_id,))
            row = cursor.fetchone()

        if not row:
            print("\033[91m[!] Scan-ID nicht gefunden.\033[0m")
            return

        ts, target, profile, summary, full_data = row
        data = safe_parse_data(full_data)

        # Dateinamen sicher machen
        safe_target = re.sub(r'[^a-zA-Z0-9]', '_', target)
        filename = f"{REPORT_DIR}/Deep_Report_{safe_target}_ID{scan_id}.md"
        
        with open(filename, "w") as f:
            f.write(f"# 🛡️ Detaillierter Audit Bericht: {target}\n\n")
            f.write(f"**Zeitstempel:** {ts}  \n")
            f.write(f"**Profil:** {profile}  \n")
            f.write(f"**ID:** {scan_id}\n\n")
            
            f.write("## 🤖 KI-Zusammenfassung\n")
            f.write(f"{summary or 'Keine Zusammenfassung verfügbar.'}\n\n")
            
            f.write("## 🌐 Netzwerk-Funde\n")
            ports = data.get('useful_ports', [])
            f.write(f"**Offene Ports:** {', '.join(map(str, ports)) if ports else 'Keine'}\n\n")
            
            f.write("### Banner-Informationen\n")
            banners = data.get('port_banners', {})
            if banners:
                for port, banner in banners.items():
                    f.write(f"- **Port {port}:** `{banner}`\n")
            else:
                f.write("*Keine Banner-Daten verfügbar.*\n")
            
            f.write("\n## 💀 Exploit-Analyse\n")
            msf = data.get('msf_modules', [])
            f.write(f"### Metasploit Module ({len(msf)})\n")
            for mod in msf:
                f.write(f"- `{mod}`\n")
            
            edb = data.get('exploit_db_results', [])
            f.write(f"\n### Exploit-DB ({len(edb)})\n")
            for res in edb:
                f.write(f"- {res}\n")

            f.write("\n## 🕸️ Web-Audit (Nikto-Lite)\n")
            nikto = data.get('nikto_findings', [])
            for find in nikto:
                f.write(f"- {find}\n")

        print(f"\033[92m[+] Bericht erfolgreich generiert: {filename}\033[0m")

    except Exception as e:
        print(f"\033[91m[!] Kritischer Fehler beim Generieren: {e}\033[0m")

def main():
    init_reports()
    os.system('clear')
    print("\033[96m")
    print("   📊 UserLAnd Smart-Agent: REPORT GENERATOR v1.1")
    print("   ============================================\033[0m")
    
    scans = fetch_scans()
    if not scans:
        print("Keine Scans in der Datenbank gefunden.")
        return

    print(f"{'ID':<5} | {'Zeitstempel':<20} | {'Ziel':<20} | {'Profil'}")
    print("-" * 75)
    for s in scans:
        print(f"{s[0]:<5} | {s[1]:<20} | {s[2]:<20} | {s[3]}")

    print("\n" + "-" * 75)
    choice = input("\033[93mGeben Sie die ID für den Bericht ein (oder 'q' zum Beenden): \033[0m").strip()
    
    if choice.lower() == 'q':
        return
    
    if choice.isdigit():
        generate_markdown_report(int(choice))
    else:
        print("\033[91m[!] Ungültige Eingabe.\033[0m")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nBeendet.")
